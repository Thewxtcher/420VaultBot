# 420bot.py (The Unified, All-Powerful Nexus Script - Complete and Final Version)

import discord
from discord.ext import commands
import asyncio
import random
import os
import re
import logging
import sys
import sqlite3 
from urllib.parse import urlparse
from typing import List, Dict, Any, Optional, Tuple
import subprocess




# -----------------------------
# ADMIN ROLE DECORATOR
# -----------------------------
# Change this to the name of your Discord admin role if needed
ADMIN_ROLE_NAME = "VaultAdmin"

def is_admin_role():
    """Checks if the command user has administrator permissions or a specific role."""
    async def predicate(ctx):
        # Check Discord built-in administrator permission first
        if ctx.author.guild_permissions.administrator:
            return True
        # Check if user has the specific admin role
        return any(role.name == ADMIN_ROLE_NAME for role in ctx.author.roles)
    return commands.check(predicate)

# --- VAULT WHISPERER CONFIGURATION CONSTANTS (Hardcoded for directness) ---
VAULT_PATH = "/mnt/e/420 VAULT" 
DATABASE_PATH = "./data/vault_files.db" 
MAX_DISCORD_FILE_SIZE = 25 * 1024 * 1024 # 25 MB in bytes (standard non-Nitro limit)


# --- ORIGINAL 420BOT CONFIGURATION SECTION: Adjust these values to control your bot! ---
PREFIX = "#" 
BOT_TOKEN = "MTQ2NjU4MjcwMjkyNzkwOTA0Mw.GVEK40.cIwF6AWAi956u5aqjp8W7Qem_S122ibmz6kzLs" # YOUR BOT TOKEN DIRECTLY HERE!
LINKS_FILES = [
    "lists.txt",
    "lists_part_2.txt",
    "lists_part_3.txt"
]
TARGET_CHANNEL_NAMES = [ 
    "zenology-bank", "serum-1-and-2-banks", "portal-banks", "midi", 
    "gross-beat-presets", "omnisphere-bank", "loops", "fx-sounds",
    "presets-banks", "🥁-drumkits-sounds", "one-shots",  
    "🔓-cracked-plugins", "🔓keygens"          
]
MAX_SEARCH_RESULTS_DISPLAY = 25


# --- Ensure data and log directories exist for ALL components ---
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(PROJECT_ROOT, 'data') 
LOGS_DIR = os.path.join(DATA_DIR, 'logs')
os.makedirs(DATA_DIR, exist_ok=True) 
os.makedirs(LOGS_DIR, exist_ok=True) 

# --- Logging Setup for the entire bot ---
logging.basicConfig(
    level=logging.INFO, 
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(LOGS_DIR, 'combined_bot.log')), # Main log file
        logging.StreamHandler(sys.stdout) # Also output to console
    ]
)
log = logging.getLogger("420Bot_Unified") # Unified logger for the entire bot


# --- GLOBAL VARIABLES & BOT INITIALIZATION (from user's 420bot.py, adapted) ---
all_loaded_links = [] 
resolved_target_channels = {} 

intents = discord.Intents.default()
intents.messages = True
intents.guilds = True
intents.message_content = True 
intents.members = True 

# Instantiate the bot
bot = commands.Bot(command_prefix=PREFIX, intents=intents)

# --- DATABASE.PY (Integrated directly) ---
class DatabaseManager:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self._initialize_db()
        log.info(f"DatabaseManager initialized for '{self.db_path}'") 

    def _initialize_db(self):
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS vault_files (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    filename TEXT NOT NULL,
                    full_path TEXT NOT NULL UNIQUE,
                    folder TEXT NOT NULL,
                    extension TEXT NOT NULL,
                    file_size INTEGER NOT NULL,
                    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    modified_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    checksum TEXT UNIQUE
                )
            ''')
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_filename ON vault_files (filename COLLATE NOCASE)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_folder ON vault_files (folder COLLATE NOCASE)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_extension ON vault_files (extension)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_file_size ON vault_files (file_size)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_checksum ON vault_files (checksum)")
            conn.commit()
        log.info("Database schema and indices verified/created.")

    def _execute_query(self, query: str, params: tuple = ()) -> List[Dict[str, Any]]:
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row
                cursor = conn.cursor()
                cursor.execute(query, params)
                results = [dict(row) for row in cursor.fetchall()]
                return results
        except sqlite3.Error as e:
            log.error(f"Database error during query: {query} with params {params}. Error: {e}")
            return []

    def get_file_by_id(self, file_id: int) -> Optional[Dict[str, Any]]:
        sql_query = "SELECT id, filename, full_path, folder, extension, file_size FROM vault_files WHERE id = ?"
        results = self._execute_query(sql_query, (file_id,))
        return results[0] if results else None

    def search_files(self, query_string: str, limit: int = 10) -> List[Dict[str, Any]]:
        if not query_string:
            return []
        keywords = query_string.split()
        conditions = []
        params = []
        for keyword in keywords:
            conditions.append("(filename COLLATE NOCASE LIKE ? OR folder COLLATE NOCASE LIKE ?)")
            params.extend([f"%{keyword}%", f"%{keyword}%"])
        where_clause = " AND ".join(conditions)
        sql_query = f"""
            SELECT id, filename, folder, extension, file_size FROM vault_files
            WHERE {where_clause}
            ORDER BY filename COLLATE NOCASE
            LIMIT ?
        """
        params.append(limit)
        return self._execute_query(sql_query, tuple(params))

    def get_random_file(self) -> Optional[Dict[str, Any]]:
        sql_query = "SELECT id, filename, full_path, folder, extension, file_size FROM vault_files ORDER BY RANDOM() LIMIT 1"
        results = self._execute_query(sql_query)
        return results[0] if results else None

    def get_stats(self) -> Dict[str, Any]:
        total_files_query = "SELECT COUNT(*) FROM vault_files"
        total_size_query = "SELECT SUM(file_size) FROM vault_files"
        last_modified_query = "SELECT MAX(modified_at) FROM vault_files" 
        total_files = self._execute_query(total_files_query)[0]['COUNT(*)']
        total_size_bytes = self._execute_query(total_size_query)[0]['SUM(file_size)'] or 0
        last_scan_time = self._execute_query(last_modified_query)[0]['MAX(modified_at)']
        return {
            "total_indexed_files": total_files,
            "total_storage_size_bytes": total_size_bytes,
            "last_scan_time": last_scan_time
        }

    def search_by_extension(self, extension: str, limit: int = 10) -> List[Dict[str, Any]]:
        clean_ext = extension.lower().lstrip('.')
        sql_query = """
            SELECT id, filename, folder, extension, file_size FROM vault_files
            WHERE extension = ?
            ORDER BY filename COLLATE NOCASE
            LIMIT ?
        """
        return self._execute_query(sql_query, (clean_ext, limit))

    def search_by_size(self, operator: str, value_bytes: int, limit: int = 10) -> List[Dict[str, Any]]:
        if operator not in ('>', '<', '=', '>=', '<='):
            log.error(f"Invalid size operator: {operator}")
            return []
        sql_query = f"""
            SELECT id, filename, folder, extension, file_size FROM vault_files
            WHERE file_size {operator} ?
            ORDER BY file_size DESC
            LIMIT ?
        """
        return self._execute_query(sql_query, (value_bytes, limit))

    def search_by_music_terminology(self, terms: List[str], limit: int = 10) -> List[Dict[str, Any]]:
        if not terms:
            return []
        
        conditions = []
        params = []
        
        for term in terms:
            conditions.append("(filename COLLATE NOCASE LIKE ? OR folder COLLATE NOCASE LIKE ?)")
            params.extend([f"%{term}%", f"%{term}%"])
        
        where_clause = " AND ".join(conditions)
        sql_query = f"""
            SELECT id, filename, folder, extension, file_size FROM vault_files
            WHERE {where_clause}
            ORDER BY filename COLLATE NOCASE
            LIMIT ?
        """
        params.append(limit)
        return self._execute_query(sql_query, tuple(params))


    def get_all_files_paginated(self, page: int, page_size: int = 20) -> List[Dict[str, Any]]:
        offset = (page - 1) * page_size
        sql_query = "SELECT id, filename, folder, extension, file_size FROM vault_files ORDER BY folder, filename LIMIT ? OFFSET ?"
        return self._execute_query(sql_query, (page_size, offset))

    def get_folder_contents_paginated(self, folder_path: str, page: int, page_size: int = 20) -> List[Dict[str, Any]]:
        offset = (page - 1) * page_size
        sql_query = """
            SELECT id, filename, folder, extension, file_size FROM vault_files 
            WHERE folder COLLATE NOCASE LIKE ? 
            ORDER BY filename COLLATE NOCASE LIMIT ? OFFSET ?
        """
        return self._execute_query(sql_query, (f"{folder_path}%", page_size, offset))

    def get_unique_folders_paginated(self, parent_folder: str = '', page: int = 1, page_size: int = 10) -> List[str]:
        offset = (page - 1) * page_size 
        search_path_prefix = os.path.join(parent_folder, '')
        
        sql_query = f"""
            SELECT DISTINCT folder
            FROM vault_files
            WHERE folder LIKE ?
            ORDER BY folder COLLATE NOCASE
            LIMIT ? OFFSET ?
        """
        params = (f"{search_path_prefix}%", page_size, offset)
        full_folders = [row['folder'] for row in self._execute_query(sql_query, params)]
        
        unique_subfolders = set()
        for fpath in full_folders:
            relative_path = os.path.relpath(fpath, parent_folder)
            if relative_path == ".": continue
            first_segment = relative_path.split(os.sep)[0]
            unique_subfolders.add(os.path.join(parent_folder, first_segment))
        return sorted(list(unique_subfolders))
    
    def count_files_in_folder(self, folder_path: str) -> int:
        sql_query = """
            SELECT COUNT(*) FROM vault_files 
            WHERE folder COLLATE NOCASE LIKE ? 
        """
        result = self._execute_query(sql_query, (f"{folder_path}%",))
        return result[0]['COUNT(*)'] if result else 0

    def count_unique_subfolders(self, parent_folder: str = '') -> int:
        search_path_prefix = os.path.join(parent_folder, '')
        full_folders = [row['folder'] for row in self._execute_query("SELECT DISTINCT folder FROM vault_files WHERE folder LIKE ?", (f"{search_path_prefix}%",))]
        unique_next_level_folders = set()
        for fpath in full_folders:
            if fpath == parent_folder: continue
            relative_path = os.path.relpath(fpath, parent_folder)
            if relative_path == ".": continue
            first_segment = relative_path.split(os.sep)[0]
            if first_segment:
                unique_next_level_folders.add(first_segment)
        return len(unique_next_level_folders)


# --- UTILS.PY (Integrated directly) ---

def format_bytes(size_bytes: int) -> str:
    if size_bytes == 0:
        return "0 B"
    units = ("B", "KB", "MB", "GB", "TB")
    i = 0
    while size_bytes >= 1024 and i < len(units) - 1:
        size_bytes /= 1024
        i += 1
    return f"{size_bytes:.2f} {units[i]}"

def parse_size_string(size_string: str) -> Optional[int]:
    size_string = size_string.strip().upper()
    if not size_string:
        return None
    try:
        if size_string.endswith("KB"):
            value = float(size_string[:-2]) * 1024
        elif size_string.endswith("MB"):
            value = float(size_string[:-2]) * 1024**2
        elif size_string.endswith("GB"):
            value = float(size_string[:-2]) * 1024**3
        elif size_string.endswith("TB"):
            value = float(size_string[:-2]) * 1024**4
        elif size_string.isdigit():
            value = float(size_string)
        else:
            return None
        return int(value)
    except ValueError:
        return None

def paginate_list(data_list: List[Any], page: int, page_size: int) -> Tuple[List[Any], int]:
    if not isinstance(data_list, list):
        log.error(f"paginate_list received non-list data: {type(data_list)}")
        return [], 0
    total_items = len(data_list)
    if total_items == 0:
        return [], 0
    total_pages = (total_items + page_size - 1) // page_size
    if page < 1:
        page = 1
    elif page > total_pages:
        page = total_pages
    start_index = (page - 1) * page_size
    end_index = start_index + page_size
    return data_list[start_index:end_index], total_pages

async def run_indexer_script_async():
    project_root = os.path.dirname(os.path.abspath(sys.argv[0]))
    indexer_script_path = os.path.join(project_root, 'indexer.py')

    if not os.path.exists(indexer_script_path):
        log.error(f"Indexer script not found at: {indexer_script_path}")
        raise FileNotFoundError(f"Indexer script not found: {indexer_script_path}")

    command = [sys.executable, indexer_script_path]
    log.info(f"Starting indexer script in background: {' '.join(command)}")
    try:
        process = await asyncio.create_subprocess_exec(
            *command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        stdout, stderr = await process.communicate()
        if stdout:
            log.info(f"Indexer (stdout):\n{stdout.decode().strip()}")
        if stderr:
            log.error(f"Indexer (stderr):\n{stderr.decode().strip()}")
        
        if process.returncode != 0:
            log.error(f"Indexer script exited with non-zero code: {process.returncode}")
            raise Exception(f"Indexer script failed with code {process.returncode}")
        log.info("Indexer script completed successfully.")
    except Exception as e:
        log.critical(f"Failed to run indexer script asynchronously: {e}", exc_info=True)
        raise

# --- Instantiate Database Manager ---
# This must happen after the DatabaseManager class is defined.
db_manager = DatabaseManager(DATABASE_PATH)


# --- ORIGINAL 420BOT Helper Functions (now defined in global scope for clarity) ---
# (load_all_links_from_files, resolve_target_channels, get_clean_url_path, search_links_by_keyword, dispatch_random_match)

def load_all_links_from_files(filenames: list):
    """Loads all links from a list of specified text files into a single list."""
    links = set() 
    total_files_processed = 0
    total_links_found_in_files = 0
    
    for filename in filenames:
        try:
            with open(os.path.join(PROJECT_ROOT, filename), 'r', encoding='utf-8') as f: # Use PROJECT_ROOT for filenames
                links_in_current_file = 0
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#') and not line.startswith('---'):
                        links.add(line)
                        links_in_current_file += 1
            log.info(f"Successfully loaded {links_in_current_file} links from '{filename}'.")
            total_files_processed += 1
            total_links_found_in_files += links_in_current_file
        except FileNotFoundError:
            log.warning(f"The file '{filename}' was not found. Skipping this file.")
        except Exception as e:
            log.error(f"Failed to load links from '{filename}': {e}. Skipping this file.")
            
    log.info(f"Finished loading from {total_files_processed} files. Total unique links loaded: {len(links)}.")
    return list(links) 

async def resolve_target_channels():
    """
    Resolves TARGET_CHANNEL_NAMES to actual Discord Channel objects across all guilds the bot is in.
    Stores resolved objects in `resolved_target_channels` dictionary.
    """
    global resolved_target_channels
    resolved_target_channels.clear() 

    log.info("Attempting to resolve configured target channel names to objects...")
    
    for guild in bot.guilds:
        log.info(f"  Searching in guild: '{guild.name}' ({guild.id})")
        for target_name in TARGET_CHANNEL_NAMES:
            channel = discord.utils.get(guild.text_channels, name=target_name) 
            if not channel: 
                 channel = discord.utils.get(guild.text_channels, name=target_name.lower())

            if channel:
                if channel.permissions_for(guild.me).send_messages:
                    if target_name.lower() not in resolved_target_channels: 
                        resolved_target_channels[target_name.lower()] = channel
                        log.info(f"    Resolved '{target_name}' in '{guild.name}' to {channel.mention} (ID: {channel.id})")
                else:
                    log.warning(f"    Bot lacks 'Send Messages' permission in '{channel.name}' ({channel.id}) in guild '{guild.name}'. Skipping.")

    if not resolved_target_channels:
        log.warning("No target channels were successfully resolved or bot lacks permissions in them. Check `TARGET_CHANNEL_NAMES` and bot's guild permissions.")
    else:
        log.info(f"Successfully resolved {len(resolved_target_channels)} unique channel names to objects.")

def get_clean_url_path(url):
    """
    Extracts a clean, lowercase path from a URL for better keyword matching.
    Removes common file extensions, kit/preset/sound terms, and replaces
    hyphens/underscores with spaces.
    """
    parsed_url = urlparse(url)
    path = parsed_url.path.strip('/').replace('-', ' ').replace('_', ' ') 
    
    path = re.sub(r'\.(html|php|asp|aspx|jsp|htm|exe|zip|rar|mp3|wav|midi|dmg|pkg)$', '', path, flags=re.IGNORECASE)
    
    path = re.sub(r'\b(free|download|kit|kits|pack|packs|preset|presets|bank|banks|vst|midi|loops|one\s*shots|drum\s*kits|sound|sounds|windows|mac|macos|installer|win|setup)\b', '', path, flags=re.IGNORECASE).strip()
    
    path = re.sub(r'\s+', ' ', path).strip()
    return path.lower()

def search_links_by_keyword(search_terms: list[str]):
    """
    Searches all loaded links where ALL provided search_terms are found in their cleaned URL paths.
    Includes special, more explicit matching logic for platform/type keywords.
    Returns a list of matching links.
    """
    if not all_loaded_links or not search_terms:
        return []

    matching_links = []
    
    for link in all_loaded_links:
        raw_path_lower = urlparse(link).path.strip('/').lower()
        cleaned_path_lower = get_clean_url_path(link)
        
        all_terms_match = True
        for term in search_terms:
            term_lower = term.lower()
            term_found_in_link = False

            if term_lower == "win":
                if "windows" in raw_path_lower or ".exe" in raw_path_lower or "installer-win" in raw_path_lower or "win-installer" in raw_path_lower or "for-windows" in raw_path_lower:
                    term_found_in_link = True
            elif term_lower == "mac":
                if "mac" in raw_path_lower or "macos" in raw_path_lower or ".dmg" in raw_path_lower or ".pkg" in raw_path_lower or "installer-mac" in raw_path_lower or "for-mac" in raw_path_lower:
                    term_found_in_link = True
            elif term_lower == "installer":
                if "installer" in raw_path_lower or ".exe" in raw_path_lower or ".dmg" in raw_path_lower or ".pkg" in raw_path_lower or "setup" in raw_path_lower:
                    term_found_in_link = True
            elif term_lower in cleaned_path_lower: 
                term_found_in_link = True
            
            if not term_found_in_link:
                all_terms_match = False
                break 
        
        if all_terms_match:
            matching_links.append(link)
    
    return matching_links

async def dispatch_random_match(ctx, search_query_original: str, target_channel_obj: discord.TextChannel, matching_links: list):
    """
    Internal helper: Sends a random match from the provided list of matching links
    to the specified channel object.
    """
    if not matching_links:
        await ctx.send(f"No kits found matching '{search_query_original}' in the loaded list. This should not happen if called correctly.")
        return

    random_match = random.choice(matching_links)

    try:
        await target_channel_obj.send(f"**Kit found for '{search_query_original}'**: {random_match}")
        await ctx.send(f"Dispatched link for '{search_query_original}' to {target_channel_obj.mention}.")
        log.info(f"Sent search result '{random_match}' to #{target_channel_obj.name} for keyword '{search_query_original}'.")
    except discord.Forbidden:
        await ctx.send(f"ERROR: I lack permissions to send messages to {target_channel_obj.mention}.")
        log.error(f"No permission to send messages to channel #{target_channel_obj.name} ({target_channel_obj.id}).")
    except Exception as e:
        await ctx.send(f"ERROR: Failed to send link to {target_channel_obj.mention}: {e}")
        log.error(f"Failed to send link to channel #{target_channel_obj.name} ({target_channel_obj.id}): {e}")


# --- Discord Bot Events and Commands (Unified) ---

@bot.event
async def on_ready():
    log.info(f"Unified Bot '{bot.user.name}' has awakened! Connected to Discord.")
    print(f"\n[Unified Bot '{bot.user.name}' has awakened! Connected to Discord.]")
    log.info(f"Bot ID: {bot.user.id}")
    print(f"Bot ID: {bot.user.id}")
    log.info(f"Invite URL: https://discord.com/oauth2/authorize?client_id=1466582702927909043&permissions=2147483648&scope=bot%20applications.commands") 
    print(f"Invite URL: https://discord.com/oauth2/authorize?client_id=1466582702927909043&permissions=2147483648&scope=bot%20applications.commands") 

    global all_loaded_links
    all_loaded_links = load_all_links_from_files(LINKS_FILES) 
    await resolve_target_channels() 

    if not all_loaded_links:
        log.critical(f"No external links loaded from '{LINKS_FILES}'. Link search commands will be limited.")
    else:
        log.info(f"Bot is ready to search {len(all_loaded_links)} external links.")

    # --- Clear any lingering slash commands ---
    # This ensures only prefix commands are active
    try:
        log.info("Clearing old slash commands to ensure a clean prefix-only interface.")
        bot.tree.clear_commands(guild=None) # Clears all global slash commands
        await bot.tree.sync(guild=None) # Sync the empty tree
        log.info("Old slash commands cleared and tree synced.")
    except Exception as e:
        log.error(f"Failed to clear old slash commands: {e}", exc_info=True)


    log.info("Unified Bot is fully ready and operational with prefix commands.")
    print("[Unified Bot is fully ready and operational with prefix commands.]\n")


@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.MissingPermissions):
        await ctx.send(f"You lack the necessary permissions to perform '{ctx.command.name}'.")
    elif isinstance(error, commands.MissingRequiredArgument):
        await ctx.send(f"A component of your command is missing. Usage: `{ctx.prefix}{ctx.command.name} {ctx.command.signature}`")
    elif isinstance(error, commands.CommandNotFound):
        pass 
    else:
        log.error(f"An unexpected error occurred: {error}", exc_info=True)
        await ctx.send(f"An unknown force briefly resisted my command: `{error}`. I shall overcome!")


# --- ORIGINAL 420BOT Prefix Commands ---
# -----------------------------
# 420VaultBot Full Commands List (Cleaned & Fixed)
# -----------------------------

import discord
from discord.ext import commands
import random
import io
import os
import re
# Ensure your db_manager, log, and other globals are defined before this file runs:
# db_manager = DatabaseManager('./data/vault_files.db')
# resolved_target_channels = {}
# TARGET_CHANNEL_NAMES = ["general", "music", "kits"]
# PREFIX = "!"
# all_loaded_links = []

MAX_SEARCH_RESULTS_DISPLAY = 10
MAX_DISCORD_FILE_SIZE = 8 * 1024 * 1024  # example 8MB limit
PREMIUM_FOLDERS = []  # define premium folders
PREMIUM_ENTITLEMENT_NAME = "Premium Access"
VAULT_PATH = "./data/vault_files"  # adjust to your folder path

# -----------------------------
# ORIGINAL 420BOT Prefix Commands
# -----------------------------

# ------------------------
# Fixed Vault Commands
# ------------------------

@bot.command(name="vault_list", help="List files and subfolders in a specified 420Vault folder.")
async def vault_list(ctx, *, folder: str = ""):
    base = VAULT_PATH
    target = os.path.join(base, folder) if folder else base

    # Use search_files with folder filter
    all_files = db_manager.search_files([])  # get everything
    results = [f for f in all_files if f["folder"].startswith(target)]

    if not results:
        await ctx.send("Vault folder is empty or not found.")
        return

    embed = discord.Embed(title=f"📁 Vault List: /{folder or ''}", color=0x2ecc71)

    # Show only filenames and subfolders in this folder
    for f in results[:25]:
        name = f["filename"]
        size = format_bytes(f["file_size"])
        embed.add_field(name=name, value=f"Size: {size}", inline=False)

    await ctx.send(embed=embed)

@bot.command(name="reindex_vault", help="[ADMIN] Triggers a full re-index of the 420Vault.")
@is_admin_role()  # make sure only admins can run
async def reindex_vault(ctx):
    await ctx.send("⚙️ Starting 420Vault re-index. This may take a moment...")

    try:
        # Run the indexer asynchronously
        process = await asyncio.create_subprocess_exec(
            "python3", "indexer.py",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )

        stdout, stderr = await process.communicate()

        if process.returncode == 0:
            output = stdout.decode().strip()
            await ctx.send(f"✅ 420Vault re-index complete!\n```\n{output[:1500]}\n```")
        else:
            error = stderr.decode().strip()
            await ctx.send(f"❌ Re-index failed with errors:\n```\n{error[:1500]}\n```")

    except Exception as e:
        await ctx.send(f"❌ An unexpected error occurred:\n```\n{str(e)}\n```")

@bot.command(name="vault_random", help="Pull a random audio file from the 420Vault.")
async def vault_random(ctx):
    files = db_manager.get_all_files()
    if not files:
        await ctx.send("Vault is empty.")
        return

    f = random.choice(files)
    embed = discord.Embed(title="🎲 Random Vault File", color=0x3498db)
    embed.add_field(name="File", value=f["filename"], inline=False)
    embed.add_field(name="Folder", value=f["folder"], inline=False)
    embed.add_field(name="Size", value=format_bytes(f["file_size"]), inline=True)
    embed.add_field(name="ID", value=f["id"], inline=True)
    await ctx.send(embed=embed)


@bot.command(name="vault_search_size", help="Searches 420Vault for files by size (e.g., '#vault_search_size 10MB').")
async def vault_search_size(ctx, size: str):
    max_size = parse_size(size)
    if max_size is None:
        await ctx.send("Invalid size. Example: `10MB`")
        return

    results = db_manager.search_by_size(max_size)
    if not results:
        await ctx.send("No matching files.")
        return

    embed = discord.Embed(title=f"📦 Files ≤ {size}", color=0xf39c12)
    for f in results[:20]:
        embed.add_field(
            name=f["filename"],
            value=f"Size: {format_bytes(f['file_size'])} | ID: {f['id']}",
            inline=False
        )
    await ctx.send(embed=embed)


@bot.command(name="vault_search_terms", help="Searches 420Vault for music production terminology matches.")
async def vault_search_terms(ctx, *, terms: str):
    results = db_manager.search_files(terms.split())
    if not results:
        await ctx.send("No matches found.")
        return

    embed = discord.Embed(title=f"🔎 Search: {terms}", color=0x9b59b6)
    for f in results[:20]:
        embed.add_field(
            name=f["filename"],
            value=f"Folder: {f['folder']} | ID: {f['id']}",
            inline=False
        )
    await ctx.send(embed=embed)


@bot.command(name="vault_search_type", help="Searches 420Vault for files by extension (e.g., '#vault_search_type wav').")
async def vault_search_type(ctx, extension: str):
    ext = extension.lstrip(".").lower()
    results = db_manager.search_by_extension(ext)

    if not results:
        await ctx.send(f"No .{ext} files found.")
        return

    embed = discord.Embed(title=f"📂 .{ext} Files", color=0x1abc9c)
    for f in results[:20]:
        embed.add_field(
            name=f["filename"],
            value=f"Size: {format_bytes(f['file_size'])} | ID: {f['id']}",
            inline=False
        )
    await ctx.send(embed=embed)


@bot.command(name="vault_stats", help="Show 420Vault indexing statistics.")
async def vault_stats(ctx):
    stats = db_manager.get_stats()

    embed = discord.Embed(title="📊 420Vault Stats", color=0x2ecc71)
    embed.add_field(name="Total Files", value=stats.get("total_files", 0))
    embed.add_field(name="Total Folders", value=stats.get("total_folders", 0))
    embed.add_field(name="Total Size", value=format_bytes(stats.get("total_size", 0)))
    embed.add_field(name="Largest File", value=stats.get("largest_file", "N/A"))
    await ctx.send(embed=embed)


@bot.command(
    name="searchkit",
    help=f"Searches for kits by multiple keywords (e.g., 'omnisphere win installer') and displays up to {MAX_SEARCH_RESULTS_DISPLAY} random matches from external links."
)
@commands.has_permissions(send_messages=True)
async def search_kit_command(ctx, *, search_query: str):
    search_terms = search_query.lower().split()
    await ctx.send(f"🔎 **Searching external links for kits matching:** `{ ' '.join(search_terms) }`")

    if not all_loaded_links:
        await ctx.send("❌ **ERROR:** No links loaded. Use `!reloadlinks` after adding link files.")
        return

    matching_links = search_links_by_keyword(search_terms)

    if not matching_links:
        await ctx.send(f"⚠️ No kits found in external links for: `{ ' '.join(search_terms) }`")
        return

    display_links = random.sample(
        matching_links,
        min(len(matching_links), MAX_SEARCH_RESULTS_DISPLAY)
    )

    EMBED_LINK_LIMIT = 10 
    chunks = [
        display_links[i:i + EMBED_LINK_LIMIT]
        for i in range(0, len(display_links), EMBED_LINK_LIMIT)
    ]

    for idx, chunk in enumerate(chunks, start=1):
        embed = discord.Embed(
            title="🎧 External Link Kit Search Results",
            description=(
                f"**Query:** `{ ' '.join(search_terms) }`\n"
                f"**Total Matches:** `{len(matching_links)}`\n"
                f"**Showing:** `{len(display_links)}`"
            ),
            color=discord.Color.dark_purple()
        )

        for i, link in enumerate(chunk, start=1 + (idx - 1) * EMBED_LINK_LIMIT):
            embed.add_field(
                name=f"Result #{i}",
                value=f"[Click to access kit]({link})",
                inline=False
            )

        embed.set_footer(
            text="Use more keywords to narrow results • Results are randomly sampled"
        )

        await ctx.send(embed=embed)

    if len(matching_links) > MAX_SEARCH_RESULTS_DISPLAY:
        await ctx.send(
            f"➕ `{len(matching_links) - MAX_SEARCH_RESULTS_DISPLAY}` more matches found.\n"
            f"Refine your search or use `!sendlink` to pull a random one."
        )

    log.info(
        f"[SEARCHKIT] {ctx.author} searched '{search_query}' "
        f"({len(matching_links)} matches) in #{ctx.channel.name}"
    )

@bot.command(name="version", aliases=["about", "info"])
async def version_command(ctx):
    embed = discord.Embed(
        title="420VaultBot",
        description="Private search engine inside Discord",
        color=0x2f3136
    )
    embed.add_field(name="Version", value="Beta 3.4", inline=True)
    embed.add_field(name="Status", value="Live", inline=True)
    embed.add_field(
        name="Development",
        value="Actively maintained. Future patches, features, and vault expansions planned.",
        inline=False
    )
    embed.set_footer(text="The Keys of Sorrow 🔑")

    await ctx.send(embed=embed)

@bot.command(name="exportserver", aliases=["servermap", "channels"])
@commands.has_permissions(administrator=True)
async def export_server(ctx):
    guild = ctx.guild
    lines = []

    lines.append(f"Server: {guild.name}")
    lines.append("=" * 40)

    # Categories + channels
    for category in guild.categories:
        lines.append(f"\n[Category] {category.name}")
        for channel in category.channels:
            ch_type = channel.type.name
            lines.append(f"  - {channel.name} ({ch_type})")

    # Channels without category
    uncategorized = [c for c in guild.channels if c.category is None]
    if uncategorized:
        lines.append("\n[No Category]")
        for channel in uncategorized:
            ch_type = channel.type.name
            lines.append(f"  - {channel.name} ({ch_type})")

    text_output = "\n".join(lines)

    file = discord.File(
        fp=io.StringIO(text_output),
        filename=f"{guild.name}_structure.txt"
    )

    await ctx.send(
        content="🗂️ Server structure export:",
        file=file
    )

@bot.command(name="sendlink", help="Searches for a kit by keyword(s) and sends a random match to a named channel.")
@commands.has_permissions(send_messages=True) 
async def send_link_by_search_and_channel(ctx, search_query: str, target_discord_channel_name: str):
    search_terms = search_query.split() 
    await ctx.send(f"Searching external links for kits matching '{' '.join(search_terms)}' to send to channel '{target_discord_channel_name}'...")

    final_target_channel_obj = resolved_target_channels.get(target_discord_channel_name.lower())

    if not final_target_channel_obj:
        await ctx.send(f"ERROR: Channel '{target_discord_channel_name}' not found or I lack permissions for it. Please use `!showchannels` to see available resolved channels.")
        return
    
    if not final_target_channel_obj.permissions_for(final_target_channel_obj.guild.me).send_messages:
        await ctx.send(f"ERROR: I lack permissions to send messages in the specified channel {final_target_channel_obj.mention}.")
        return

    matching_links = search_links_by_keyword(search_terms)

    if not matching_links:
        await ctx.send(f"No kits found matching '{' '.join(search_terms)}' in the loaded list. Try different keywords!")
        return

    await dispatch_random_match(ctx, search_query, final_target_channel_obj, matching_links) 

@bot.command(name="reloadlinks", help="Reloads all links from the configured LINKS_FILES.")
@commands.has_permissions(administrator=True) 
async def reload_links_command(ctx):
    global all_loaded_links
    all_loaded_links = load_all_links_from_files(LINKS_FILES) 
    if all_loaded_links:
        await ctx.send(f"Successfully reloaded {len(all_loaded_links)} links from {len(LINKS_FILES)} files.")
    else:
        await ctx.send(f"WARNING: No links loaded after reload from the configured LINKS_FILES.")

@bot.command(name="resolvelinks", help="Re-resolves configured target channel names to objects.")
@commands.has_permissions(administrator=True)
async def resolve_channels_cmd(ctx):
    await ctx.send("Re-resolving configured target channel names to objects now...")
    await resolve_target_channels()
    if resolved_target_channels:
        resolved_mentions = [c.mention for c in resolved_target_channels.values()]
        await ctx.send(f"Successfully resolved {len(resolved_target_channels)} channels: {', '.join(resolved_mentions)}")
    else:
        await ctx.send("No channels could be resolved. Check `TARGET_CHANNEL_NAMES` and bot's permissions.")

@bot.command(name="showchannels", help="Shows configured Discord channel names and their resolved status.")
@commands.has_permissions(manage_channels=True)
async def show_configured_channels(ctx):
    if not TARGET_CHANNEL_NAMES:
        await ctx.send("No target channel names are currently configured in `TARGET_CHANNEL_NAMES` list.")
        return

    response_lines = ["**Configured Target Discord Channels:**"]
    if not resolved_target_channels:
        response_lines.append("  (No channels currently resolved - use `!resolvelinks` or check bot's permissions and guild presence.)")
    
    for name in sorted(TARGET_CHANNEL_NAMES): 
        channel_obj = resolved_target_channels.get(name.lower())
        if channel_obj:
            response_lines.append(f"  - `{name}` (Resolved to: {channel_obj.mention} - ID: `{channel_obj.id}`)")
        else:
            response_lines.append(f"  - `{name}` (Not yet resolved or bot lacks access)")
    
    await ctx.send("\n".join(response_lines))

@bot.command(name="status", help="Displays the bot's current operational status.")
async def bot_status(ctx):
    status_msg = f"Intelligent Retriever Bot is online!\n" \
                 f"Loaded external links: {len(all_loaded_links)}\n" \
                 f"Resolved target channels: {len(resolved_target_channels)}\n" \
                 f"Prefix: `{PREFIX}`"
    await ctx.send(status_msg)

# -----------------------------
# ADMIN COMMANDS FOR BOT CONTROL
# -----------------------------

@bot.command(name="lockdown", help="[ADMIN] Activates bot lockdown mode and locks public channels. Usage: #lockdown")
@is_admin_role()
async def lockdown_command(ctx):
    global bot_lockdown_active
    if not bot_lockdown_active:
        await ctx.send("🚨 **BOT LOCKDOWN INITIATED!** Disabling most commands and locking public channels.")
        log.critical(f"Bot lockdown initiated by {ctx.author.name} ({ctx.author.id}).")
        await lockdown_channels(ctx.guild, ctx.channel)
    else:
        await ctx.send("🚨 Bot is already in lockdown mode and channels are locked.")

@bot.command(name="unlock", help="[ADMIN] Deactivates bot lockdown mode and unlocks public channels. Usage: #unlock")
@is_admin_role()
async def unlock_command(ctx):
    global bot_lockdown_active
    if bot_lockdown_active:
        await ctx.send("✅ **BOT LOCKDOWN DEACTIVATED.** Re-enabling all commands and unlocking public channels.")
        log.critical(f"Bot lockdown deactivated by {ctx.author.name} ({ctx.author.id}).")
        await unlock_channels_func(ctx.guild, ctx.channel)
    else:
        await ctx.send("✅ Bot is not currently in lockdown mode or channels are not locked.")

# -----------------------------
# 420Vault Commands
# -----------------------------

@bot.command(name="vault_search", help="Searches the 420Vault for audio assets by keywords (e.g., '#vault_search drum loop').")
@commands.has_permissions(send_messages=True)
async def vault_search_command(ctx, *, query_and_pagination: str):
    db_manager.log_user_activity(ctx.author.id, 'search_vault_keywords')  # Log search activity
    # Expects "query [limit:X] [page:Y]"
    parts = query_and_pagination.split(' ')
    query_terms = []
    limit = 5
    page = 1
    
    for part in parts:
        if part.lower().startswith("limit:"):
            try:
                limit = int(part[len("limit:"):])
            except ValueError:
                await ctx.send("Invalid limit. Must be a number.")
                return
        elif part.lower().startswith("page:"):
            try:
                page = int(part[len("page:"):])
            except ValueError:
                await ctx.send("Invalid page. Must be a number.")
                return
        else:
            query_terms.append(part)
            
    query = " ".join(query_terms)

    if not query:
        await ctx.send("Please provide keywords to search the vault. Usage: `!vault_search query [limit:X] [page:Y]`")
        return

    await ctx.send(f"🔎 **Searching 420Vault for:** `{query}`, Limit: {limit}, Page: {page}...")

    all_results = db_manager.search_files(query, limit=1000)  # Fetch more to paginate locally
    paginated_results, total_pages = paginate_list(all_results, page, limit)

    if not paginated_results:
        await ctx.send(f"No results found for '{query}' on page {page} in 420Vault. The vault remains silent.")
        return

    embed = create_base_embed(ctx, f"🎧 420Vault Search Results for '{query}' (Page {page}/{total_pages})",
                            description=f"Found {len(all_results)} total matches. Use `{PREFIX}download_vault <ID>` for a file:",
                            color=discord.Color(0x420690))
    
    for i, file_data in enumerate(paginated_results):
        filename = file_data['filename']
        relative_folder = os.path.relpath(file_data['folder'], VAULT_PATH)
        display_folder = relative_folder if relative_folder != "." else "/"
        size = format_bytes(file_data['file_size']) 
        extension = file_data['extension'].upper().lstrip('.')

        # Check for premium folder access
        is_premium_file_concept = any(pf.lower() in display_folder.lower() for pf in PREMIUM_FOLDERS)
        if is_premium_file_concept and not db_manager.user_has_entitlement(ctx.author.id, PREMIUM_ENTITLEMENT_NAME):
            download_status = "🔒 PREMIUM ACCESS REQUIRED"
        elif file_data['file_size'] > MAX_DISCORD_FILE_SIZE:
            download_status = "❌ Too large for Discord"
        else:
            download_status = f"✅ Downloadable (ID: {file_data['id']})"
        
        file_info_value = (
            f"**Path:** `{display_folder}`\n"
            f"**Size:** {size} | **Type:** {extension}\n"
            f"{download_status}"
        )
        if file_data.get('bpm'):
            file_info_value += f"\n**BPM:** `{file_data['bpm']}`"
        if file_data.get('audio_key'):
            file_info_value += f" | **Key:** `{file_data['audio_key']}`"
        if file_data.get('time_signature'):
            file_info_value += f" | **Time Sig:** `{file_data['time_signature']}`"
            
        embed.add_field(
            name=f"**{i+1}. {filename}**",
            value=file_info_value,
            inline=False
        )
    
    embed.set_footer(text=f"Information wants to be free, and so do YOU. | Next: `{PREFIX}vault_search \"{query}\" page:{page+1}`")
    await ctx.send(embed=embed)




# --- Bot Execution ---

def run_bot():
    if BOT_TOKEN == "YOUR_BOT_TOKEN_HERE" or BOT_TOKEN is None:
        log.critical("ERROR: BOT_TOKEN is not set. Please update the 'CONFIGURATION SECTION' with your bot's token.")
        print("ERROR: BOT_TOKEN is not set. Please update the 'CONFIGURATION SECTION' with your bot's token.")
        print("Your bot cannot awaken without its divine key!")
        return
    try:
        log.info("Attempting to run bot with provided BOT_TOKEN.")
        bot.run(BOT_TOKEN)
    except discord.LoginFailure:
        log.critical("ERROR: Invalid BOT_TOKEN provided. Ensure your BOT_TOKEN is correct and valid in the CONFIGURATION SECTION.")
        print("ERROR: Invalid BOT_TOKEN provided. Ensure your BOT_TOKEN is correct and valid in the CONFIGURATION SECTION.")
    except Exception as e:
        log.critical(f"ERROR: Bot encountered an unexpected error during Discord connection: {e}", exc_info=True)
        print(f"ERROR: Bot encountered an unexpected error during Discord connection: {e}")

if __name__ == "__main__":
    run_bot()
