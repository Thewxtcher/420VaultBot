import sqlite3
import logging
from typing import List, Dict, Any, Optional, Tuple # Added Tuple for pagination return types
import os

log = logging.getLogger("VaultWhisperer_DB")

class DatabaseManager:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self._initialize_db()
        log.info(f"DatabaseManager initialized for '{self.db_path}'")

    def _initialize_db(self):
        """Ensures the database and schema are correctly established."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS vault_files (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    filename TEXT NOT NULL,
                    full_path TEXT NOT NULL UNIQUE,
                    folder TEXT NOT NULL,
                    extension TEXT NOT NULL,
                    file_size INTEGER NOT NULL,
                    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    modified_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    checksum TEXT UNIQUE -- MD5/SHA256 for robust duplicate detection and integrity verification
                )
            ''')
            # Create/recreate indexes - ensuring speed for search queries
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_filename ON vault_files (filename COLLATE NOCASE)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_folder ON vault_files (folder COLLATE NOCASE)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_extension ON vault_files (extension)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_checksum ON vault_files (checksum)") 
            conn.commit()
        log.info("Database schema and indices verified/created.")

    def _execute_query(self, query: str, params: tuple = ()) -> List[Dict[str, Any]]:
        """Helper to execute SQL queries and return results as dictionaries."""
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row # Return rows as dict-like objects
                cursor = conn.cursor()
                cursor.execute(query, params)
                results = [dict(row) for row in cursor.fetchall()]
                return results
        except sqlite3.Error as e:
            log.error(f"Database error during query: {query} with params {params}. Error: {e}")
            return []

    def get_file_by_id(self, file_id: int) -> Optional[Dict[str, Any]]:
        """Retrieves a single file by its ID."""
        sql_query = "SELECT id, filename, full_path, folder, extension, file_size FROM vault_files WHERE id = ?"
        results = self._execute_query(sql_query, (file_id,))
        return results[0] if results else None

    def search_files(self, query_string: str, limit: int = 10) -> List[Dict[str, Any]]:
        """
        Performs a multi-keyword, case-insensitive search across filename and folder.
        """
        if not query_string:
            return []

        keywords = query_string.split()
        conditions = []
        params = []

        for keyword in keywords:
            conditions.append("(filename COLLATE NOCASE LIKE ? OR folder COLLATE NOCASE LIKE ?)")
            params.extend([f"%{keyword}%", f"%{keyword}%"])
        
        where_clause = " AND ".join(conditions)
        sql_query = f"""
            SELECT id, filename, folder, extension, file_size FROM vault_files
            WHERE {where_clause}
            ORDER BY filename COLLATE NOCASE
            LIMIT ?
        """
        params.append(limit)
        
        log.debug(f"Executing search query: {sql_query} with params: {params}")
        return self._execute_query(sql_query, tuple(params))

    def get_random_file(self) -> Optional[Dict[str, Any]]:
        """Retrieves a single random file from the index."""
        sql_query = "SELECT id, filename, full_path, folder, extension, file_size FROM vault_files ORDER BY RANDOM() LIMIT 1"
        results = self._execute_query(sql_query)
        return results[0] if results else None

    def get_stats(self) -> Dict[str, Any]:
        """Retrieves indexing statistics."""
        total_files_query = "SELECT COUNT(*) FROM vault_files"
        total_size_query = "SELECT SUM(file_size) FROM vault_files"
        last_modified_query = "SELECT MAX(modified_at) FROM vault_files" 

        total_files = self._execute_query(total_files_query)[0]['COUNT(*)']
        total_size_bytes = self._execute_query(total_size_query)[0]['SUM(file_size)'] or 0
        last_scan_time = self._execute_query(last_modified_query)[0]['MAX(modified_at)']

        return {
            "total_indexed_files": total_files,
            "total_storage_size_bytes": total_size_bytes,
            "last_scan_time": last_scan_time
        }
    
    # --- NEW / ENHANCED PAGINATION & FOLDER NAVIGATION METHODS ---

    def count_total_files(self) -> int:
        """Counts the total number of files in the vault."""
        sql_query = "SELECT COUNT(*) FROM vault_files"
        result = self._execute_query(sql_query)
        return result[0]['COUNT(*)'] if result else 0

    def get_all_files_paginated(self, page: int, page_size: int = 20) -> List[Dict[str, Any]]:
        """Retrieves a paginated list of all indexed files."""
        offset = (page - 1) * page_size
        sql_query = "SELECT id, filename, folder, extension, file_size FROM vault_files ORDER BY folder, filename LIMIT ? OFFSET ?"
        return self._execute_query(sql_query, (page_size, offset))

    def count_files_in_folder(self, folder_path_abs: str) -> int:
        """Counts files directly within a given absolute folder path."""
        # Ensure path ends with os.sep for correct LIKE matching if it's a directory
        # e.g., /mnt/e/VAULT/Drums/ -> /mnt/e/VAULT/Drums/%
        search_path_prefix = os.path.join(folder_path_abs, '')
        sql_query = """
            SELECT COUNT(*) FROM vault_files 
            WHERE folder LIKE ?
        """
        result = self._execute_query(sql_query, (f"{search_path_prefix}%",))
        return result[0]['COUNT(*)'] if result else 0
    
    def get_folder_contents_paginated(self, folder_path_abs: str, page: int, page_size: int = 20) -> List[Dict[str, Any]]:
        """
        Retrieves a paginated list of files directly within a specific absolute folder path.
        """
        offset = (page - 1) * page_size
        search_path_prefix = os.path.join(folder_path_abs, '')
        sql_query = """
            SELECT id, filename, folder, extension, file_size FROM vault_files 
            WHERE folder LIKE ? 
            ORDER BY filename COLLATE NOCASE LIMIT ? OFFSET ?
        """
        return self._execute_query(sql_query, (f"{search_path_prefix}%", page_size, offset))
    
    def count_unique_subfolders(self, parent_folder_abs: str = '') -> int:
        """
        Counts the number of *immediate* unique subfolders within a given absolute parent path.
        """
        parent_folder_abs = os.path.abspath(parent_folder_abs)
        search_prefix = os.path.join(parent_folder_abs, '')
        
        # This query gets all *indexed* folders that are descendants of parent_folder_abs.
        sql_query = "SELECT DISTINCT folder FROM vault_files WHERE folder LIKE ?"
        all_descendant_folders = [row['folder'] for row in self._execute_query(sql_query, (f"{search_prefix}%",))]

        unique_next_level_folders = set()
        for fpath in all_descendant_folders:
            # Calculate the relative path from the parent
            try:
                relative_path = os.path.relpath(fpath, parent_folder_abs)
            except ValueError: 
                # Handles cases where fpath might not be a subpath (e.g., if parent_folder_abs is root and fpath is /another/dir)
                continue 
            
            # If relative_path is '.', it means fpath is the parent_folder_abs itself, skip it.
            if relative_path == ".":
                continue
            
            # Get the first segment of the relative path, which is the immediate subfolder name
            first_segment = relative_path.split(os.sep)[0]
            if first_segment: # Ensure it's not empty
                unique_next_level_folders.add(first_segment)
        return len(unique_next_level_folders)

    def get_unique_subfolders_paginated(self, parent_folder_abs: str = '', page: int = 1, page_size: int = 10) -> Tuple[List[str], int]:
        """
        Retrieves a paginated list of *immediate* unique subfolders within a given absolute parent path.
        Returns a tuple of (list of absolute subfolder paths, total number of pages).
        """
        parent_folder_abs = os.path.abspath(parent_folder_abs)
        search_prefix = os.path.join(parent_folder_abs, '')

        # Fetch all distinct descendant folders
        sql_query = "SELECT DISTINCT folder FROM vault_files WHERE folder LIKE ?"
        all_descendant_folders = [row['folder'] for row in self._execute_query(sql_query, (f"{search_prefix}%",))]
        
        unique_next_level_full_paths = set()
        for fpath in all_descendant_folders:
            try:
                relative_path = os.path.relpath(fpath, parent_folder_abs)
            except ValueError:
                continue

            if relative_path == ".":
                continue
            
            first_segment = relative_path.split(os.sep)[0]
            if first_segment:
                unique_next_level_full_paths.add(os.path.join(parent_folder_abs, first_segment))
        
        sorted_unique_folders = sorted(list(unique_next_level_full_paths))
        
        # Now paginate this sorted list (using utils.paginate_list logic here for convenience, 
        # but the list is already derived from a filtered DB query)
        total_items = len(sorted_unique_folders)
        if total_items == 0:
            return [], 0
        
        total_pages = (total_items + page_size - 1) // page_size
        if page < 1:
            page = 1
        elif page > total_pages:
            page = total_pages
            
        start_index = (page - 1) * page_size
        end_index = start_index + page_size
        
        paginated_folders = sorted_unique_folders[start_index:end_index]
        return paginated_folders, total_pages


    def search_by_extension(self, extension: str, limit: int = 10) -> List[Dict[str, Any]]:
        clean_ext = extension.lower().lstrip('.')
        sql_query = """
            SELECT id, filename, folder, extension, file_size FROM vault_files
            WHERE extension = ?
            ORDER BY filename COLLATE NOCASE
            LIMIT ?
        """
        return self._execute_query(sql_query, (clean_ext, limit))

    def search_by_size(self, operator: str, value_bytes: int, limit: int = 10) -> List[Dict[str, Any]]:
        if operator not in ('>', '<', '=', '>=', '<='):
            log.error(f"Invalid size operator: {operator}")
            return []
        sql_query = f"""
            SELECT id, filename, folder, extension, file_size FROM vault_files
            WHERE file_size {operator} ?
            ORDER BY file_size DESC
            LIMIT ?
        """
        return self._execute_query(sql_query, (value_bytes, limit))

    def search_by_music_terminology(self, terms: List[str], limit: int = 10) -> List[Dict[str, Any]]:
        if not terms:
            return []
        
        conditions = []
        params = []
        
        for term in terms:
            conditions.append("(filename COLLATE NOCASE LIKE ? OR folder COLLATE NOCASE LIKE ?)")
            params.extend([f"%{term}%", f"%{term}%"])
        
        where_clause = " AND ".join(conditions)
        sql_query = f"""
            SELECT id, filename, folder, extension, file_size FROM vault_files
            WHERE {where_clause}
            ORDER BY filename COLLATE NOCASE
            LIMIT ?
        """
        params.append(limit)
        return self._execute_query(sql_query, tuple(params))