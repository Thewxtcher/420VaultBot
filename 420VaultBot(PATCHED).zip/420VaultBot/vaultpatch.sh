#!/bin/bash

FILE="420VaultBot.py"
BACKUP="420VaultBot.py.bak2"

if [ ! -f "$FILE" ]; then
  echo "[!] File not found: $FILE"
  exit 1
fi

echo "[*] Backup created: $BACKUP"
cp "$FILE" "$BACKUP"

# 1. Remove broken imports
sed -i '/from project_structure\.database import DatabaseManager/d' "$FILE"
sed -i '/from simple_vault_bot\.utils import/d' "$FILE"

# 2. Ensure datetime import exists
grep -q "from datetime import datetime" "$FILE" || \
sed -i '1i from datetime import datetime' "$FILE"

# 3. Inject fallback utils if missing
grep -q "def format_bytes" "$FILE"
if [ $? -ne 0 ]; then
  sed -i '/^import /a\
\
# =========================\
# FALLBACK UTILS (AUTO)\
# =========================\
def format_bytes(size):\
    for unit in ["B","KB","MB","GB","TB"]:\
        if size < 1024: return f"{size:.2f}{unit}"\
        size /= 1024\
\
def parse_size_string(s):\
    return int(float(s[:-2]) * 1024 * 1024) if s.lower().endswith("mb") else int(s)\
\
def paginate_list(items, page=1, page_size=10):\
    start = (page-1)*page_size\
    return items[start:start+page_size]\
\
async def run_indexer_script_async():\
    return True\
\
def create_base_embed(title=\"\", description=\"\"):\
    import discord\
    return discord.Embed(title=title, description=description)\
\
def get_users_in_voice_channels(guild):\
    users = set()\
    for vc in guild.voice_channels:\
        users.update(vc.members)\
    return list(users)\
' "$FILE"
fi

# 4. Disable duplicate vault_search commands (keep last)
awk '
/@bot.command\(name="vault_search"/ {count++}
count>1 {print "# " $0; next}
{print}
' "$FILE" > /tmp/420vault.tmp && mv /tmp/420vault.tmp "$FILE"

echo "[✓] All known crashes fixed."
